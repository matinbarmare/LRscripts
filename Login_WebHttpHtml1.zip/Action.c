Action()
{

	/*2: Navigate to "https://cswebtst.te.eg/arsys/home"*/

	/* Request with GET method to URL "https://cswebtst.te.eg/arsys/home" failed during recording. Server response : 401*/

	web_set_sockets_option("SSL_VERSION", "AUTO");

	/*3.1: Click on User Name textbox*/

	web_reg_find("Text=Hash Handler", 
		LAST);

	web_submit_data("start", 
		"Action=https://csrssotst.te.eg/rsso/start", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://cswebtst.te.eg/arsys/home", 
		"Snapshot=t1.inf", 
		"Mode=HTTP", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=goto", "Value=https://cswebtst.te.eg/arsys/home", ENDITEM, 
		"Name=tenant", "Value=*@*", ENDITEM, 
		LAST);

	web_reg_find("Text=BMC Remedy Single Sign-On", 
		LAST);

/*Correlation comment - Do not change!  Original value='20200206123348' Name ='v' Type ='ResponseBased'*/
	web_reg_save_param_regexp(
		"ParamName=v",
		"RegExp=href=\"/rsso/img/icons/favicon_48x48\\.ico\\?v=(.*?)\"\\ ",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

	web_submit_data("start_2", 
		"Action=https://csrssotst.te.eg/rsso/start", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://csrssotst.te.eg/rsso/start", 
		"Snapshot=t2.inf", 
		"Mode=HTTP", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=url_hash_handler", "Value=true", ENDITEM, 
		"Name=goto", "Value=https://cswebtst.te.eg/arsys/home", ENDITEM, 
		"Name=tenant", "Value=*@*", ENDITEM, 
		LAST);

	web_url("rsso-login.css",
		"URL=https://csrssotst.te.eg/rsso/css/rsso-login.css?v={v}",
		"Resource=1",
		"RecContentType=text/css",
		"Referer=https://csrssotst.te.eg/rsso/start",
		"Snapshot=t3.inf",
		LAST);

	web_url("change-password.css",
		"URL=https://csrssotst.te.eg/rsso/css/change-password.css?v={v}",
		"Resource=1",
		"RecContentType=text/css",
		"Referer=https://csrssotst.te.eg/rsso/start",
		"Snapshot=t4.inf",
		LAST);

	web_url("serialize.js",
		"URL=https://csrssotst.te.eg/rsso/js/app/serialize.js?v={v}",
		"Resource=1",
		"RecContentType=application/javascript",
		"Referer=https://csrssotst.te.eg/rsso/start",
		"Snapshot=t5.inf",
		LAST);

	web_url("promise.js",
		"URL=https://csrssotst.te.eg/rsso/js/polyfill/promise.js?v={v}",
		"Resource=1",
		"RecContentType=application/javascript",
		"Referer=https://csrssotst.te.eg/rsso/start",
		"Snapshot=t6.inf",
		LAST);

	web_url("app.js",
		"URL=https://csrssotst.te.eg/rsso/js/app/app.js?v={v}",
		"Resource=1",
		"RecContentType=application/javascript",
		"Referer=https://csrssotst.te.eg/rsso/start",
		"Snapshot=t7.inf",
		LAST);

	web_url("unfetch.js",
		"URL=https://csrssotst.te.eg/rsso/js/polyfill/unfetch.js?v={v}",
		"Resource=1",
		"RecContentType=application/javascript",
		"Referer=https://csrssotst.te.eg/rsso/start",
		"Snapshot=t8.inf",
		LAST);

	web_url("change-password.js",
		"URL=https://csrssotst.te.eg/rsso/js/app/change-password.js?v={v}",
		"Resource=1",
		"RecContentType=application/javascript",
		"Referer=https://csrssotst.te.eg/rsso/start",
		"Snapshot=t9.inf",
		LAST);

	web_url("bmc_logo_header.svg",
		"URL=https://csrssotst.te.eg/rsso/img/bmc/bmc_logo_header.svg",
		"Resource=1",
		"RecContentType=image/svg+xml",
		"Referer=https://csrssotst.te.eg/rsso/css/rsso-login.css?v={v}",
		"Snapshot=t10.inf",
		LAST);

	web_url("footer-logo.svg",
		"URL=https://csrssotst.te.eg/rsso/img/login/footer-logo.svg",
		"Resource=1",
		"RecContentType=image/svg+xml",
		"Referer=https://csrssotst.te.eg/rsso/css/rsso-login.css?v={v}",
		"Snapshot=t11.inf",
		LAST);

	web_url("DPL_Iconfont_v.0.0.2.woff",
		"URL=https://csrssotst.te.eg/rsso/fonts/DPL_Iconfont_v.0.0.2.woff",
		"Resource=1",
		"RecContentType=font/woff",
		"Referer=https://csrssotst.te.eg/rsso/css/rsso-login.css?v={v}",
		"Snapshot=t12.inf",
		LAST);

	web_url("HelveticaNeueLTW1G-Lt.woff",
		"URL=https://csrssotst.te.eg/rsso/fonts/Helvetica/HelveticaNeueLTW1G-Lt.woff",
		"Resource=1",
		"RecContentType=font/woff",
		"Referer=https://csrssotst.te.eg/rsso/css/rsso-login.css?v={v}",
		"Snapshot=t13.inf",
		LAST);

	web_url("HelveticaNeueLTW1G-Roman.woff",
		"URL=https://csrssotst.te.eg/rsso/fonts/Helvetica/HelveticaNeueLTW1G-Roman.woff",
		"Resource=1",
		"RecContentType=font/woff",
		"Referer=https://csrssotst.te.eg/rsso/css/rsso-login.css?v={v}",
		"Snapshot=t14.inf",
		LAST);

	web_url("login-cover-5.jpg", 
		"URL=https://csrssotst.te.eg/rsso/img/login/backgrounds/login-cover-5.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://csrssotst.te.eg/rsso/start", 
		"Snapshot=t15.inf", 
		LAST);

	/*3.2: Type Performance.Test.0001 in User Name textbox*/

	/*3.3: Click on Password passwordbox*/

	/*3.4: Type ******** in Password passwordbox*/

	/*3.5: Click on Log In button*/

	lr_think_time(14);

	web_submit_data("start_3", 
		"Action=https://csrssotst.te.eg/rsso/start", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://csrssotst.te.eg/rsso/start", 
		"Snapshot=t16.inf", 
		"Mode=HTTP", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=reauth", "Value=false", ENDITEM, 
		"Name=new-hpassword", "Value=", ENDITEM, 
		"Name=hpassword", "Value=vsnvxkxsmvkskzkjkmkk", ENDITEM, 
		"Name=authorizationRequest", "Value=", ENDITEM, 
		"Name=allow-from-domain", "Value=", ENDITEM, 
		"Name=rsso-agent-referer", "Value=", ENDITEM, 
		"Name=bypass-referer", "Value=", ENDITEM, 
		"Name=cross-sso-orig-domains", "Value=", ENDITEM, 
		"Name=rsso_preauth", "Value=", ENDITEM, 
		"Name=auth-index", "Value=0", ENDITEM, 
		"Name=tenant", "Value=*@*", ENDITEM, 
		"Name=goto", "Value=https://cswebtst.te.eg/arsys/home", ENDITEM, 
		"Name=bypass-auth", "Value=", ENDITEM, 
		"Name=url_hash_handler", "Value=true", ENDITEM, 
		"Name=password", "Value=", ENDITEM, 
		"Name=user-name", "Value=Performance.Test.0001", ENDITEM, 
		"Name=redirect", "Value=0", ENDITEM, 
		LAST);

	web_url("home", 
		"URL=https://cswebtst.te.eg/arsys/home", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://csrssotst.te.eg/rsso/start", 
		"Snapshot=t17.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("moment.min.js", 
		"URL=https://cswebtst.te.eg/arsys/resources/javascript/momentjs/moment.min.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://cswebtst.te.eg/arsys/home", 
		"Snapshot=t18.inf", 
		LAST);

	web_url("moment-timezone-with-data.min.js", 
		"URL=https://cswebtst.te.eg/arsys/resources/javascript/momentjs/moment-timezone-with-data.min.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://cswebtst.te.eg/arsys/home", 
		"Snapshot=t19.inf", 
		LAST);

	web_reg_find("Text=\n", 
		LAST);

/*Correlation comment - Do not change!  Original value='dff97f8f' Name ='cacheid' Type ='ResponseBased'*/
	web_reg_save_param_regexp(
		"ParamName=cacheid",
		"RegExp=cacheid=(.*?)\\\r\\\n",
		SEARCH_FILTERS,
		"Scope=Headers",
		"IgnoreRedirections=No",
		"RequestUrl=*/NewView/*",
		LAST);

	web_submit_data("home_2", 
		"Action=https://cswebtst.te.eg/arsys/home", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://cswebtst.te.eg/arsys/home", 
		"Snapshot=t20.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=timezone", "Value=Africa/Cairo", ENDITEM, 
		"Name=goto", "Value=null", ENDITEM, 
		"Name=tzind", "Value=1", ENDITEM, 
		LAST);

	web_url("boomerang.js",
		"URL=https://cswebtst.te.eg/arsys/resources/javascript/9.1.10.002%20202010021144/boomerang.js",
		"Resource=1",
		"RecContentType=application/x-javascript",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid={cacheid}",
		"Snapshot=t21.inf",
		LAST);

	web_url("bootstrap.js",
		"URL=https://cswebtst.te.eg/arsys/resources/javascript/9.1.10.002%20202010021144/bootstrap.js",
		"Resource=1",
		"RecContentType=application/x-javascript",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid={cacheid}",
		"Snapshot=t22.inf",
		LAST);

	web_url("resize.css",
		"URL=https://cswebtst.te.eg/arsys/resources/javascript/9.1.10.002%20202010021144/YUI/assets/skins/sam/resize.css",
		"Resource=1",
		"RecContentType=text/css",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid={cacheid}",
		"Snapshot=t23.inf",
		LAST);

	web_url("jquery.treetable.css",
		"URL=https://cswebtst.te.eg/arsys/resources/javascript/9.1.10.002%20202010021144/JQuery/jquery.treetable.css",
		"Resource=1",
		"RecContentType=text/css",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid={cacheid}",
		"Snapshot=t24.inf",
		LAST);

	web_url("jquery-3.4.0.min.js",
		"URL=https://cswebtst.te.eg/arsys/resources/javascript/9.1.10.002%20202010021144/JQuery/jquery-3.4.0.min.js",
		"Resource=1",
		"RecContentType=application/x-javascript",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid={cacheid}",
		"Snapshot=t25.inf",
		LAST);

	web_url("LocalizedMessages_en_US.js",
		"URL=https://cswebtst.te.eg/arsys/resources/javascript/9.1.10.002%20202010021144/LocalizedMessages_en_US.js",
		"Resource=1",
		"RecContentType=application/x-javascript",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid={cacheid}",
		"Snapshot=t26.inf",
		LAST);

	web_url("jquery-ui.min.js",
		"URL=https://cswebtst.te.eg/arsys/resources/javascript/9.1.10.002%20202010021144/JQuery-UI/jquery-ui.min.js",
		"Resource=1",
		"RecContentType=application/x-javascript",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid={cacheid}",
		"Snapshot=t27.inf",
		LAST);

	web_url("jquery-ui.min.css",
		"URL=https://cswebtst.te.eg/arsys/resources/javascript/9.1.10.002%20202010021144/JQuery-UI/jquery-ui.min.css",
		"Resource=1",
		"RecContentType=text/css",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid={cacheid}",
		"Snapshot=t28.inf",
		LAST);

	web_url("jquery.treetable.min.js",
		"URL=https://cswebtst.te.eg/arsys/resources/javascript/9.1.10.002%20202010021144/JQuery/jquery.treetable.min.js",
		"Resource=1",
		"RecContentType=application/x-javascript",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid={cacheid}",
		"Snapshot=t29.inf",
		LAST);

	web_url("dff97f8f.js",
		"URL=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/form.js/{cacheid}.js?format=html",
		"Resource=1",
		"RecContentType=text/javascript",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid={cacheid}",
		"Snapshot=t30.inf",
		LAST);

	web_url("purify.min.js",
		"URL=https://cswebtst.te.eg/arsys/resources/javascript/9.1.10.002%20202010021144/DOMPurify/purify.min.js",
		"Resource=1",
		"RecContentType=application/x-javascript",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid={cacheid}",
		"Snapshot=t31.inf",
		LAST);

	web_url("ckeditor.js",
		"URL=https://cswebtst.te.eg/arsys/resources/javascript/9.1.10.002%20202010021144/ckeditor/ckeditor.js",
		"Resource=1",
		"RecContentType=application/x-javascript",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid={cacheid}",
		"Snapshot=t32.inf",
		LAST);

	web_url("ARSystem.css",
		"URL=https://cswebtst.te.eg/arsys/resources/stylesheets/9.1.10.002%20202010021144/moz/ARSystem.css",
		"Resource=1",
		"RecContentType=text/css",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid={cacheid}",
		"Snapshot=t33.inf",
		LAST);

	web_url("arrow-up-white.gif",
		"URL=https://cswebtst.te.eg/arsys/resources/images/arrow-up-white.gif",
		"Resource=1",
		"RecContentType=image/gif",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid={cacheid}",
		"Snapshot=t34.inf",
		LAST);

	web_url("chunking_sprite.png",
		"URL=https://cswebtst.te.eg/arsys/resources/images/chunking_sprite.png",
		"Resource=1",
		"RecContentType=image/png",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid={cacheid}",
		"Snapshot=t35.inf",
		LAST);

	web_url("menu_down.gif",
		"URL=https://cswebtst.te.eg/arsys/resources/images/menu_down.gif",
		"Resource=1",
		"RecContentType=image/gif",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid={cacheid}",
		"Snapshot=t36.inf",
		LAST);

	web_url("arrow-down-white.gif",
		"URL=https://cswebtst.te.eg/arsys/resources/images/arrow-down-white.gif",
		"Resource=1",
		"RecContentType=image/gif",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid={cacheid}",
		"Snapshot=t37.inf",
		LAST);

	web_url("Progress_NonModal-circle.gif",
		"URL=https://cswebtst.te.eg/arsys/resources/images/Progress_NonModal-circle.gif",
		"Resource=1",
		"RecContentType=image/gif",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid={cacheid}",
		"Snapshot=t38.inf",
		LAST);

	web_url("mt_sprites.gif",
		"URL=https://cswebtst.te.eg/arsys/resources/images/mt_sprites.gif",
		"Resource=1",
		"RecContentType=image/gif",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid={cacheid}",
		"Snapshot=t39.inf",
		LAST);

	web_url("uds.js",
		"URL=https://cswebtst.te.eg/arsys/forms/csapptst/9.1.10.002%20202010021144/uds.js?462363268",
		"Resource=1",
		"RecContentType=text/javascript",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid={cacheid}",
		"Snapshot=t40.inf",
		LAST);

/*Correlation comment - Do not change!  Original value='LB0O-JO69-AGXQ-QQO2-K9FG-2O21-METT-ZHPK' Name ='sToken' Type ='ResponseBased'*/
	web_reg_save_param_regexp(
		"ParamName=sToken",
		"RegExp=window\\.sTok=\"(.*?)\";this\\.sysMsgPromptType",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

/*Correlation comment - Do not change!  Original value='1676926937000' Name ='cid' Type ='ResponseBased'*/
	web_reg_save_param_regexp(
		"ParamName=cid",
		"RegExp=this\\.cacheIDRefCount=\\{\"csapptst1\":1676923952000,\"csapptst\":(.*?)}",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

	web_url("udd.js",
		"URL=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/udd.js?ui=462363268&w=637361707074737443533A4346473A484F4D452D50414745",
		"Resource=1",
		"RecContentType=text/javascript",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid={cacheid}",
		"Snapshot=t41.inf",
		LAST);

	web_url("ClientCore.js",
		"URL=https://cswebtst.te.eg/arsys/resources/javascript/9.1.10.002%20202010021144/moz/ClientCore.js",
		"Resource=1",
		"RecContentType=application/x-javascript",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid={cacheid}",
		"Snapshot=t42.inf",
		LAST);

	web_url("ffffff9effffffc4ffffffa875ffffff96ffffffdfffffffdfffffffbcffffffe8bfffffff031fffffffa14ffffffcfffffffaa",
		"URL=https://cswebtst.te.eg/arsys/imagepool/ffffff9effffffc4ffffffa875ffffff96ffffffdfffffffdfffffffbcffffffe8bfffffff031fffffffa14ffffffcfffffffaa",
		"Resource=1",
		"RecContentType=image/png",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid={cacheid}",
		"Snapshot=t43.inf",
		LAST);

	web_url("ffffffa731ffffffeaffffffc93968ffffffe775ffffffe3ffffff851affffff87ffffffa4ffffffdd2058",
		"URL=https://cswebtst.te.eg/arsys/imagepool/ffffffa731ffffffeaffffffc93968ffffffe775ffffffe3ffffff851affffff87ffffffa4ffffffdd2058",
		"Resource=1",
		"RecContentType=image/png",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid={cacheid}",
		"Snapshot=t44.inf",
		LAST);

	web_url("ping.html",
		"URL=https://cswebtst.te.eg/arsys/resources/html/ping.html",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid={cacheid}",
		"Snapshot=t45.inf",
		"Mode=HTTP",
		LAST);

	web_url("DragDrop-Valid-single.gif",
		"URL=https://cswebtst.te.eg/arsys/resources/images/DragDrop-Valid-single.gif",
		"Resource=1",
		"RecContentType=image/gif",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid={cacheid}",
		"Snapshot=t46.inf",
		LAST);

	web_url("DragDrop-Valid-multiple.gif",
		"URL=https://cswebtst.te.eg/arsys/resources/images/DragDrop-Valid-multiple.gif",
		"Resource=1",
		"RecContentType=image/gif",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid={cacheid}",
		"Snapshot=t47.inf",
		LAST);

	web_url("68effffffa0ffffffbb5648bffffffda17aaffffff8967e1cffffffaa",
		"URL=https://cswebtst.te.eg/arsys/imagepool/68effffffa0ffffffbb5648bffffffda17aaffffff8967e1cffffffaa",
		"Resource=1",
		"RecContentType=image/png",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid={cacheid}",
		"Snapshot=t48.inf",
		LAST);

	web_url("ffffffb9ffffffc3ffffffb6fffffffbfffffff9cffffffc0ffffffbdffffffb4ffffffa5ffffff89fffffffd58fffffff9ffffffebffffffd3",
		"URL=https://cswebtst.te.eg/arsys/imagepool/ffffffb9ffffffc3ffffffb6fffffffbfffffff9cffffffc0ffffffbdffffffb4ffffffa5ffffff89fffffffd58fffffff9ffffffebffffffd3",
		"Resource=1",
		"RecContentType=image/png",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid={cacheid}",
		"Snapshot=t49.inf",
		LAST);

	web_url("ffffffc5ffffffe47425cffffff98ffffffd7ffffffbc1e3effffffa16d2d5250ffffff8a",
		"URL=https://cswebtst.te.eg/arsys/imagepool/ffffffc5ffffffe47425cffffff98ffffffd7ffffffbc1e3effffffa16d2d5250ffffff8a",
		"Resource=1",
		"RecContentType=image/png",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid={cacheid}",
		"Snapshot=t50.inf",
		LAST);

	web_url("5cffffffddffffffd3ffffff9d3affffffb8ffffffc8346affffff9b72ffffffb95effffff8a3630",
		"URL=https://cswebtst.te.eg/arsys/imagepool/5cffffffddffffffd3ffffff9d3affffffb8ffffffc8346affffff9b72ffffffb95effffff8a3630",
		"Resource=1",
		"RecContentType=image/png",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid={cacheid}",
		"Snapshot=t51.inf",
		LAST);

	web_url("DragDrop-NotValid-multiple.gif",
		"URL=https://cswebtst.te.eg/arsys/resources/images/DragDrop-NotValid-multiple.gif",
		"Resource=1",
		"RecContentType=image/gif",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid={cacheid}",
		"Snapshot=t52.inf",
		LAST);

	web_url("DragDrop-NotValid-single.gif",
		"URL=https://cswebtst.te.eg/arsys/resources/images/DragDrop-NotValid-single.gif",
		"Resource=1",
		"RecContentType=image/gif",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid={cacheid}",
		"Snapshot=t53.inf",
		LAST);

	web_url("ffffffaeffffffbfffffff89ffffffeb4ffffffd9ffffffde5a4fffffffe1ffffffcc1ffffffedffffffc7ffffffcdffffff82",
		"URL=https://cswebtst.te.eg/arsys/imagepool/ffffffaeffffffbfffffff89ffffffeb4ffffffd9ffffffde5a4fffffffe1ffffffcc1ffffffedffffffc7ffffffcdffffff82",
		"Resource=1",
		"RecContentType=image/png",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid={cacheid}",
		"Snapshot=t54.inf",
		LAST);

	web_url("ffffffd625321c7c3b63ffffff84ffffffd4ffffffceffffff87ffffffba792affffffe062",
		"URL=https://cswebtst.te.eg/arsys/imagepool/ffffffd625321c7c3b63ffffff84ffffffd4ffffffceffffff87ffffffba792affffffe062",
		"Resource=1",
		"RecContentType=image/png",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid={cacheid}",
		"Snapshot=t55.inf",
		LAST);

/* Added by Async CodeGen.
ID=LongPoll_0
ScanType = Recording

The following URLs are considered part of this conversation:
	https://cswebtst.te.eg/arsys/BackChannel/

TODO - The following callbacks have been added to AsyncCallbacks.c.
Add your code to the callback implementations as necessary.
	LongPoll_0_RequestCB
	LongPoll_0_ResponseCB
 */
	web_reg_async_attributes("ID=LongPoll_0", 
		"Pattern=LongPoll", 
		"URL=https://cswebtst.te.eg/arsys/BackChannel/", 
		"RequestCB=LongPoll_0_RequestCB", 
		"ResponseCB=LongPoll_0_ResponseCB", 
		LAST);

	web_custom_request("BackChannel",
		"URL=https://cswebtst.te.eg/arsys/BackChannel/",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid={cacheid}",
		"Snapshot=t56.inf",
		"Mode=HTTP",
		"EncType=text/plain; charset=UTF-8",
		"Body=29/GetServerTimestamp/8/csapptst&sToken={sToken}",
		LAST);

	web_url("fffffffbffffffecffffffe1ffffffb14fffffff861fffffff922b78ffffffbe19451fffffffa6fffffffe",
		"URL=https://cswebtst.te.eg/arsys/imagepool/fffffffbffffffecffffffe1ffffffb14fffffff861fffffff922b78ffffffbe19451fffffffa6fffffffe",
		"Resource=1",
		"RecContentType=image/png",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid={cacheid}",
		"Snapshot=t57.inf",
		LAST);

/* Removed by Async CodeGen.
ID = LongPoll_0
 */
	/*
 web_custom_request("BackChannel_2",
		"URL=https://cswebtst.te.eg/arsys/BackChannel/",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid=dff97f8f",
		"Snapshot=t58.inf",
		"Mode=HTTP",
		"EncType=text/plain; charset=UTF-8",
		"Body=265/SetEntryList/8/csapptst16/CS:CFG:HOME-PAGE8/csapptst25/CS:WF:AGENT-LOGIN-TRACKER0/38/1\\4\\1\\1\\536870913\\2\\1\\1\\4\\1\\1\\7\\2\\6\\0\\6/1/2/-126/1/21/Performance.Test.00015/1/1/41/41/61/024/2/9/5368709139/53687091439/2/21/Performance.Test.000110/16770724808/2/1/41/71/01/02/0/&sToken=LB0O-JO69-AGXQ-QQO2-K9FG-2O21-METT-ZHPK",
		LAST); 
	*/

/* Removed by Async CodeGen.
ID = LongPoll_0
 */
	/*
 web_custom_request("BackChannel_3",
		"URL=https://cswebtst.te.eg/arsys/BackChannel/",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid=dff97f8f",
		"Snapshot=t59.inf",
		"Mode=HTTP",
		"EncType=text/plain; charset=UTF-8",
		"Body=191/GetEntryList/8/csapptst16/CS:CFG:HOME-PAGE7/NewView8/csapptst13/CS:CFG:PEOPLE0/22/4\\1\\1\\536870973\\2\\1\\1\\6/1/2/-126/1/21/Performance.Test.00015/1/1/45/1/1/01/01/21/324/2/9/5368709329/536871035&sToken=LB0O-JO69-AGXQ-QQO2-K9FG-2O21-METT-ZHPK",
		LAST); 
	*/

/* Removed by Async CodeGen.
ID = LongPoll_0
 */
	/*
 web_custom_request("BackChannel_4",
		"URL=https://cswebtst.te.eg/arsys/BackChannel/",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid=dff97f8f",
		"Snapshot=t60.inf",
		"Mode=HTTP",
		"EncType=text/plain; charset=UTF-8",
		"Body=212/GetEntryList/8/csapptst16/CS:CFG:HOME-PAGE7/NewView8/csapptst23/CS:CFG:GROUP-MEMBERSHIP0/44/1\\4\\1\\1\\536870914\\2\\1\\1\\4\\6\\1\\700000468\\2\\0\\6/1/2/-126/1/21/Performance.Test.00015/1/1/45/1/1/01/01/21/313/1/9/700000468&sToken=LB0O-JO69-AGXQ-QQO2-K9FG-2O21-METT-ZHPK",
		LAST); 
	*/

/* Removed by Async CodeGen.
ID = LongPoll_0
 */
	/*
 web_custom_request("BackChannel_5",
		"URL=https://cswebtst.te.eg/arsys/BackChannel/",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid=dff97f8f",
		"Snapshot=t61.inf",
		"Mode=HTTP",
		"EncType=text/plain; charset=UTF-8",
		"Body=212/GetEntryList/8/csapptst16/CS:CFG:HOME-PAGE7/NewView8/csapptst23/CS:CFG:GROUP-MEMBERSHIP0/44/1\\4\\1\\1\\536870914\\2\\1\\1\\4\\6\\1\\700000469\\2\\0\\6/1/2/-126/1/21/Performance.Test.00015/1/1/45/1/1/01/01/21/313/1/9/700000469&sToken=LB0O-JO69-AGXQ-QQO2-K9FG-2O21-METT-ZHPK",
		LAST); 
	*/

/* Removed by Async CodeGen.
ID = LongPoll_0
 */
	/*
 web_custom_request("BackChannel_6",
		"URL=https://cswebtst.te.eg/arsys/BackChannel/",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid=dff97f8f",
		"Snapshot=t62.inf",
		"Mode=HTTP",
		"EncType=text/plain; charset=UTF-8",
		"Body=223/GetEntryList/8/csapptst16/CS:CFG:HOME-PAGE7/NewView8/csapptst23/CS:CFG:GROUP-MEMBERSHIP0/44/1\\4\\1\\1\\536870914\\2\\1\\1\\4\\6\\1\\700000470\\2\\0\\6/1/2/-126/1/21/Performance.Test.00015/1/1/45/1/1/01/01/21/324/2/9/5368709699/700000470&sToken=LB0O-JO69-AGXQ-QQO2-K9FG-2O21-METT-ZHPK",
		LAST); 
	*/

/* Added by Async CodeGen.
ID = LongPoll_0
 */
	web_stop_async("ID=LongPoll_0", 
		LAST);

/* Added by Async CodeGen.
ID=LongPoll_1
ScanType = Recording

The following URLs are considered part of this conversation:
	https://cswebtst.te.eg/arsys/BackChannel/

TODO - The following callbacks have been added to AsyncCallbacks.c.
Add your code to the callback implementations as necessary.
	LongPoll_1_RequestCB
	LongPoll_1_ResponseCB
 */
	web_reg_async_attributes("ID=LongPoll_1", 
		"Pattern=LongPoll", 
		"URL=https://cswebtst.te.eg/arsys/BackChannel/", 
		"RequestCB=LongPoll_1_RequestCB", 
		"ResponseCB=LongPoll_1_ResponseCB", 
		LAST);

	web_custom_request("BackChannel_7",
		"URL=https://cswebtst.te.eg/arsys/BackChannel/",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid={cacheid}",
		"Snapshot=t63.inf",
		"Mode=HTTP",
		"EncType=text/plain; charset=UTF-8",
		"Body=212/GetEntryList/8/csapptst16/CS:CFG:HOME-PAGE7/NewView8/csapptst23/CS:CFG:GROUP-MEMBERSHIP0/44/1\\4\\1\\1\\536870914\\2\\1\\1\\4\\6\\1\\536870951\\2\\0\\6/1/2/-126/1/21/Performance.Test.00015/1/1/45/1/1/01/01/21/313/1/9/536870951&sToken={sToken}",
		LAST);

/* Removed by Async CodeGen.
ID = LongPoll_1
 */
	/*
 web_custom_request("BackChannel_8",
		"URL=https://cswebtst.te.eg/arsys/BackChannel/",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid=dff97f8f",
		"Snapshot=t64.inf",
		"Mode=HTTP",
		"EncType=text/plain; charset=UTF-8",
		"Body=222/GetEntryList/8/csapptst16/CS:CFG:HOME-PAGE7/NewView8/csapptst23/CS:CFG:GROUP-MEMBERSHIP0/63/1\\4\\1\\1\\536870914\\2\\1\\1\\4\\7\\1\\536870915\\2\\4\\15\\%Administrator%\\6/1/2/-126/1/21/Performance.Test.00015/1/1/45/1/1/01/01/21/35/1/1/1&sToken=LB0O-JO69-AGXQ-QQO2-K9FG-2O21-METT-ZHPK",
		LAST); 
	*/

/* Removed by Async CodeGen.
ID = LongPoll_1
 */
	/*
 web_custom_request("BackChannel_9",
		"URL=https://cswebtst.te.eg/arsys/BackChannel/",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid=dff97f8f",
		"Snapshot=t65.inf",
		"Mode=HTTP",
		"EncType=text/plain; charset=UTF-8",
		"Body=206/GetEntryList/8/csapptst16/CS:CFG:HOME-PAGE7/NewView8/csapptst32/CS:FE:CFG:FIELD-ENGINEERS-MASTER0/38/1\\4\\1\\1\\536870913\\2\\1\\1\\4\\1\\1\\7\\2\\6\\0\\6/1/2/-126/1/21/Performance.Test.00015/1/1/45/1/1/01/01/21/35/1/1/1&sToken=LB0O-JO69-AGXQ-QQO2-K9FG-2O21-METT-ZHPK",
		LAST); 
	*/

	/*4: Click on javascript_link (2) JavaScript link*/

/* Removed by Async CodeGen.
ID = LongPoll_1
 */
	/*
 web_custom_request("BackChannel_10",
		"URL=https://cswebtst.te.eg/arsys/BackChannel/",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid=dff97f8f",
		"Snapshot=t66.inf",
		"Mode=HTTP",
		"EncType=text/plain; charset=UTF-8",
		"Body=224/GetEntryList/8/csapptst16/CS:CFG:HOME-PAGE7/NewView8/csapptst23/CS:CFG:GROUP-MEMBERSHIP0/56/1\\4\\1\\1\\536870914\\2\\1\\1\\4\\1\\1\\536870915\\2\\4\\9\\CSA Admin\\6/1/2/-126/1/21/Performance.Test.00015/1/1/45/1/1/01/01/21/313/1/9/536870915&sToken=LB0O-JO69-AGXQ-QQO2-K9FG-2O21-METT-ZHPK",
		LAST); 
	*/

/* Removed by Async CodeGen.
ID = LongPoll_1
 */
	/*
 web_custom_request("BackChannel_11",
		"URL=https://cswebtst.te.eg/arsys/BackChannel/",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid=dff97f8f",
		"Snapshot=t67.inf",
		"Mode=HTTP",
		"EncType=text/plain; charset=UTF-8",
		"Body=207/GetURLForForm/1/08/csapptst0/19/CS:WF:AGENT-CONSOLE14/FontLine_NewCS1/067/637361707074737443533A57463A4147454E542D434F4E534F4C45167707246580560/{wname:\"\",fvlist:null,wMode:2,wForceClear:1,fvSetDefaults:0}1/0&sToken=LB0O-JO69-AGXQ-QQO2-K9FG-2O21-METT-ZHPK",
		LAST); 
	*/

	web_reg_find("Text=\n", 
		LAST);

	web_url("FontLine_NewCS",
		"URL=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3AWF%3AAGENT-CONSOLE/FontLine_NewCS/?cacheid=751002d0",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid={cacheid}",
		"Snapshot=t68.inf",
		"Mode=HTTP",
		LAST);

/* Removed by Async CodeGen.
ID = LongPoll_1
 */
	/*
 web_custom_request("BackChannel_12",
		"URL=https://cswebtst.te.eg/arsys/BackChannel/",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid=dff97f8f",
		"Snapshot=t69.inf",
		"Mode=HTTP",
		"EncType=text/plain; charset=UTF-8",
		"Body=229/GetEntryList/8/csapptst16/CS:CFG:HOME-PAGE7/NewView8/csapptst23/CS:CFG:GROUP-MEMBERSHIP0/61/1\\4\\1\\1\\536870914\\2\\1\\1\\4\\1\\1\\536870915\\2\\4\\13\\CSA Sub Admin\\6/1/2/-126/1/21/Performance.Test.00015/1/1/45/1/1/01/01/21/313/1/9/536870915&sToken=LB0O-JO69-AGXQ-QQO2-K9FG-2O21-METT-ZHPK",
		LAST); 
	*/

/* Removed by Async CodeGen.
ID = LongPoll_1
 */
	/*
 web_custom_request("BackChannel_13",
		"URL=https://cswebtst.te.eg/arsys/BackChannel/",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid=dff97f8f",
		"Snapshot=t70.inf",
		"Mode=HTTP",
		"EncType=text/plain; charset=UTF-8",
		"Body=283/SetEntryList/8/csapptst16/CS:CFG:HOME-PAGE8/csapptst17/CS:WF:LoginRecord0/46/1\\4\\1\\2\\1\\1\\1\\536870913\\4\\1\\1\\536870915\\2\\1\\4\\10/2/2/-12/-439/2/21/Performance.Test.000110/16770168008/2/1/41/71/41/31/024/2/9/5368709139/53687091535/2/21/Performance.Test.00017/24599989/2/1/42/131/01/02/0/&sToken=LB0O-JO69-AGXQ-QQO2-K9FG-2O21-METT-ZHPK",
		LAST); 
	*/

	web_url("751002d0.js", 
		"URL=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3AWF%3AAGENT-CONSOLE/FontLine_NewCS/form.js/751002d0.js?format=html", 
		"Resource=1", 
		"RecContentType=text/javascript", 
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3AWF%3AAGENT-CONSOLE/FontLine_NewCS/?cacheid=751002d0", 
		"Snapshot=t71.inf", 
		LAST);

	web_url("add-ux%21csapptst",
		"URL=https://cswebtst.te.eg/arsys/imagepool/add-ux%21csapptst?cid={cid}",
		"Resource=1",
		"RecContentType=image/gif",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3AWF%3AAGENT-CONSOLE/FontLine_NewCS/?cacheid=751002d0",
		"Snapshot=t72.inf",
		LAST);

	web_url("68ffffffecffffffa51e29ffffffbeffffffe231ffffff9246ffffffd4ffffffa5ffffffd4fffffff556fffffff1", 
		"URL=https://cswebtst.te.eg/arsys/imagepool/68ffffffecffffffa51e29ffffffbeffffffe231ffffff9246ffffffd4ffffffa5ffffffd4fffffff556fffffff1", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3AWF%3AAGENT-CONSOLE/FontLine_NewCS/?cacheid=751002d0", 
		"Snapshot=t73.inf", 
		LAST);

	web_url("ffffff8bfffffff17b38ffffffbe1d6e228fffffffeffffff95ffffffea7affffffff22ffffffb4", 
		"URL=https://cswebtst.te.eg/arsys/imagepool/ffffff8bfffffff17b38ffffffbe1d6e228fffffffeffffff95ffffffea7affffffff22ffffffb4", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3AWF%3AAGENT-CONSOLE/FontLine_NewCS/?cacheid=751002d0", 
		"Snapshot=t74.inf", 
		LAST);

	web_url("white+chevron+left%21csapptst",
		"URL=https://cswebtst.te.eg/arsys/imagepool/white+chevron+left%21csapptst?cid={cid}",
		"Resource=1",
		"RecContentType=image/gif",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3AWF%3AAGENT-CONSOLE/FontLine_NewCS/?cacheid=751002d0",
		"Snapshot=t75.inf",
		LAST);

	web_url("ffffffd0ffffff854cffffff950ffffffb5ffffffbaffffffd1933ffffffad7ffffffbdffffffbdffffffe046", 
		"URL=https://cswebtst.te.eg/arsys/imagepool/ffffffd0ffffff854cffffff950ffffffb5ffffffbaffffffd1933ffffffad7ffffffbdffffffbdffffffe046", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3AWF%3AAGENT-CONSOLE/FontLine_NewCS/?cacheid=751002d0", 
		"Snapshot=t76.inf", 
		LAST);

	web_url("white+chevron+right%21csapptst",
		"URL=https://cswebtst.te.eg/arsys/imagepool/white+chevron+right%21csapptst?cid={cid}",
		"Resource=1",
		"RecContentType=image/gif",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3AWF%3AAGENT-CONSOLE/FontLine_NewCS/?cacheid=751002d0",
		"Snapshot=t77.inf",
		LAST);

/* Removed by Async CodeGen.
ID = LongPoll_1
 */
	/*
 web_custom_request("BackChannel_14",
		"URL=https://cswebtst.te.eg/arsys/BackChannel/",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid=dff97f8f",
		"Snapshot=t78.inf",
		"Mode=HTTP",
		"EncType=text/plain; charset=UTF-8",
		"Body=229/GetEntryList/8/csapptst16/CS:CFG:HOME-PAGE7/NewView8/csapptst35/CS:WF:READINESS-CUMMULATIVE-CONSOLE0/46/1\\4\\1\\1\\536871009\\2\\1\\1\\4\\1\\1\\536870959\\2\\6\\1\\6/1/2/-126/1/21/Performance.Test.00015/1/1/45/1/1/01/01/21/316/2/1/79/536870959&sToken=LB0O-JO69-AGXQ-QQO2-K9FG-2O21-METT-ZHPK",
		LAST); 
	*/

	web_url("AnimMgr.js",
		"URL=https://cswebtst.te.eg/arsys/resources/javascript/9.1.10.002%20202010021144/moz/AnimMgr.js",
		"Resource=1",
		"RecContentType=application/x-javascript",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid={cacheid}",
		"Snapshot=t79.inf",
		LAST);

	web_url("udd.js_2", 
		"URL=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3AWF%3AAGENT-CONSOLE/FontLine_NewCS/udd.js?ui=462363268&w=637361707074737443533A57463A4147454E542D434F4E534F4C451677072465805", 
		"Resource=1", 
		"RecContentType=text/javascript", 
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3AWF%3AAGENT-CONSOLE/FontLine_NewCS/?cacheid=751002d0", 
		"Snapshot=t80.inf", 
		LAST);

	web_url("401876ffffff9fffffff9728ffffffe75f2fffffffbf4b24d1cffffff99ffffffe9", 
		"URL=https://cswebtst.te.eg/arsys/imagepool/401876ffffff9fffffff9728ffffffe75f2fffffffbf4b24d1cffffff99ffffffe9", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3AWF%3AAGENT-CONSOLE/FontLine_NewCS/?cacheid=751002d0", 
		"Snapshot=t81.inf", 
		LAST);

/* Removed by Async CodeGen.
ID = LongPoll_1
 */
	/*
 web_custom_request("BackChannel_15",
		"URL=https://cswebtst.te.eg/arsys/BackChannel/",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3AWF%3AAGENT-CONSOLE/FontLine_NewCS/?cacheid=751002d0",
		"Snapshot=t82.inf",
		"Mode=HTTP",
		"EncType=text/plain; charset=UTF-8",
		"Body=196/GetEntryList/8/csapptst19/CS:WF:AGENT-CONSOLE14/FontLine_NewCS8/csapptst25/CS:CFG:APPLICATION-GROUPS0/29/4\\1\\99\\536870926\\1\\536870914\\13/1/9/5368709265/1/1/ 5/1/1/45/1/1/01/01/21/313/1/9/536870977&sToken=LB0O-JO69-AGXQ-QQO2-K9FG-2O21-METT-ZHPK",
		LAST); 
	*/

/* Removed by Async CodeGen.
ID = LongPoll_1
 */
	/*
 web_custom_request("BackChannel_16",
		"URL=https://cswebtst.te.eg/arsys/BackChannel/",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3AWF%3AAGENT-CONSOLE/FontLine_NewCS/?cacheid=751002d0",
		"Snapshot=t83.inf",
		"Mode=HTTP",
		"EncType=text/plain; charset=UTF-8",
		"Body=202/GetEntryList/8/csapptst19/CS:WF:AGENT-CONSOLE14/FontLine_NewCS8/csapptst33/CS:CFG:ESCALATION-FOLLOW-UP-USERS0/22/4\\1\\1\\536870914\\2\\1\\1\\6/1/2/-126/1/21/Performance.Test.00015/1/1/45/1/1/01/01/21/35/1/1/1&sToken=LB0O-JO69-AGXQ-QQO2-K9FG-2O21-METT-ZHPK",
		LAST); 
	*/

/* Removed by Async CodeGen.
ID = LongPoll_1
 */
	/*
 web_custom_request("BackChannel_17",
		"URL=https://cswebtst.te.eg/arsys/BackChannel/",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3AWF%3AAGENT-CONSOLE/FontLine_NewCS/?cacheid=751002d0",
		"Snapshot=t84.inf",
		"Mode=HTTP",
		"EncType=text/plain; charset=UTF-8",
		"Body=199/GetEntryList/8/csapptst19/CS:WF:AGENT-CONSOLE14/FontLine_NewCS8/csapptst25/CS:CFG:APPLICATION-GROUPS0/30/4\\1\\99\\1000000892\\1\\536870914\\15/1/10/10000008925/1/1/ 5/1/1/45/1/1/01/01/21/313/1/9/536870977&sToken=LB0O-JO69-AGXQ-QQO2-K9FG-2O21-METT-ZHPK",
		LAST); 
	*/

/* Removed by Async CodeGen.
ID = LongPoll_1
 */
	/*
 web_custom_request("BackChannel_18",
		"URL=https://cswebtst.te.eg/arsys/BackChannel/",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3AWF%3AAGENT-CONSOLE/FontLine_NewCS/?cacheid=751002d0",
		"Snapshot=t85.inf",
		"Mode=HTTP",
		"EncType=text/plain; charset=UTF-8",
		"Body=495/GetTableEntryList/8/csapptst19/CS:WF:AGENT-CONSOLE14/FontLine_NewCS10/10000008138/csapptst20/CS:WF:BULLETIN-BOARD0/1/03/1002/0/218/1\\1\\1\\1\\2\\2\\1\\4\\1\\2\\1\\1\\1\\536870922\\4\\1\\99\\536870926\\1\\536870921\\1\\4\\1\\1\\536870914\\2\\6\\0\\4\\1\\99\\536870926\\1\\536870921\\4\\1\\1\\536870914\\2\\6\\2\\4\\3\\2\\1\\2\\1\\536870916\\4\\5\\2\\1\\2\\1\\536870917\\4\\1\\1\\7\\2\\6\\1\\4\\1\\1\\536870934\\2\\0\\21/3/9/5368709262/-12/-242/3/1/ 21/Performance.Test.000110/167707246611/3/1/41/41/711/3/1/01/01/01/02/0/2/0/35/SessionExcludedTableAutoRefreshCall&sToken=LB0O-JO69-AGXQ-QQO2-K9FG-2O21-METT-ZHPK",
		LAST); 
	*/

/* Removed by Async CodeGen.
ID = LongPoll_1
 */
	/*
 web_custom_request("BackChannel_19",
		"URL=https://cswebtst.te.eg/arsys/BackChannel/",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3AWF%3AAGENT-CONSOLE/FontLine_NewCS/?cacheid=751002d0",
		"Snapshot=t86.inf",
		"Mode=HTTP",
		"EncType=text/plain; charset=UTF-8",
		"Body=213/GetEntryList/8/csapptst19/CS:WF:AGENT-CONSOLE14/FontLine_NewCS8/csapptst35/CS:WF:READINESS-CUMMULATIVE-CONSOLE0/22/4\\1\\1\\536871009\\2\\1\\1\\6/1/2/-126/1/21/Performance.Test.00015/1/1/45/1/1/01/01/21/313/1/9/536870959&sToken=LB0O-JO69-AGXQ-QQO2-K9FG-2O21-METT-ZHPK",
		LAST); 
	*/

/* Removed by Async CodeGen.
ID = LongPoll_1
 */
	/*
 web_custom_request("BackChannel_20",
		"URL=https://cswebtst.te.eg/arsys/BackChannel/",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3AWF%3AAGENT-CONSOLE/FontLine_NewCS/?cacheid=751002d0",
		"Snapshot=t87.inf",
		"Mode=HTTP",
		"EncType=text/plain; charset=UTF-8",
		"Body=196/GetEntryList/8/csapptst19/CS:WF:AGENT-CONSOLE14/FontLine_NewCS8/csapptst25/CS:CFG:APPLICATION-GROUPS0/29/4\\1\\99\\536870926\\1\\536870914\\13/1/9/5368709265/1/1/ 5/1/1/45/1/1/01/01/21/313/1/9/536870977&sToken=LB0O-JO69-AGXQ-QQO2-K9FG-2O21-METT-ZHPK",
		LAST); 
	*/

/* Removed by Async CodeGen.
ID = LongPoll_1
 */
	/*
 web_custom_request("BackChannel_21",
		"URL=https://cswebtst.te.eg/arsys/BackChannel/",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3AWF%3AAGENT-CONSOLE/FontLine_NewCS/?cacheid=751002d0",
		"Snapshot=t88.inf",
		"Mode=HTTP",
		"EncType=text/plain; charset=UTF-8",
		"Body=223/GetEntryList/8/csapptst19/CS:WF:AGENT-CONSOLE14/FontLine_NewCS8/csapptst23/CS:CFG:GROUP-MEMBERSHIP0/44/1\\4\\1\\1\\536870914\\2\\1\\1\\4\\6\\1\\700000468\\2\\0\\6/1/2/-126/1/21/Performance.Test.00015/1/1/45/1/1/01/01/21/313/1/9/536870915&sToken=LB0O-JO69-AGXQ-QQO2-K9FG-2O21-METT-ZHPK",
		LAST); 
	*/

	/*5: Activate tab #2*/

/* Removed by Async CodeGen.
ID = LongPoll_1
 */
	/*
 web_custom_request("BackChannel_22",
		"URL=https://cswebtst.te.eg/arsys/BackChannel/",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3AWF%3AAGENT-CONSOLE/FontLine_NewCS/?cacheid=751002d0",
		"Snapshot=t89.inf",
		"Mode=HTTP",
		"EncType=text/plain; charset=UTF-8",
		"Body=255/SetEntryList/8/csapptst19/CS:WF:AGENT-CONSOLE8/csapptst42/CS:CFG:CONSOLE-USER-CURRENT-GROUP-STAGINIG0/16/4\\1\\2\\2\\1\\2\\2\\2\\2/0/2/0/2/0/1/41/61/035/3/9/5368709169/5368709269/53687092748/3/5/Front12/Consumer Pre21/Performance.Test.000111/3/1/41/41/41/01/02/0/&sToken=LB0O-JO69-AGXQ-QQO2-K9FG-2O21-METT-ZHPK",
		LAST); 
	*/

/* Added by Async CodeGen.
ID = LongPoll_1
 */
	web_stop_async("ID=LongPoll_1", 
		LAST);

/* Added by Async CodeGen.
ID=LongPoll_2
ScanType = Recording

The following URLs are considered part of this conversation:
	https://cswebtst.te.eg/arsys/BackChannel/

TODO - The following callbacks have been added to AsyncCallbacks.c.
Add your code to the callback implementations as necessary.
	LongPoll_2_RequestCB
	LongPoll_2_ResponseCB
 */
	web_reg_async_attributes("ID=LongPoll_2", 
		"Pattern=LongPoll", 
		"URL=https://cswebtst.te.eg/arsys/BackChannel/", 
		"RequestCB=LongPoll_2_RequestCB", 
		"ResponseCB=LongPoll_2_ResponseCB", 
		LAST);

	web_custom_request("BackChannel_23",
		"URL=https://cswebtst.te.eg/arsys/BackChannel/",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3AWF%3AAGENT-CONSOLE/FontLine_NewCS/?cacheid=751002d0",
		"Snapshot=t90.inf",
		"Mode=HTTP",
		"EncType=text/plain; charset=UTF-8",
		"Body=202/GetEntryList/8/csapptst19/CS:WF:AGENT-CONSOLE14/FontLine_NewCS8/csapptst13/CS:CFG:PEOPLE0/22/4\\1\\1\\536870973\\2\\1\\1\\6/1/2/-126/1/21/Performance.Test.00015/1/1/45/1/1/01/01/21/324/2/9/5368709739/536870974&sToken={sToken}",
		LAST);

/* Removed by Async CodeGen.
ID = LongPoll_2
 */
	/*
 web_custom_request("BackChannel_24",
		"URL=https://cswebtst.te.eg/arsys/BackChannel/",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3AWF%3AAGENT-CONSOLE/FontLine_NewCS/?cacheid=751002d0",
		"Snapshot=t91.inf",
		"Mode=HTTP",
		"EncType=text/plain; charset=UTF-8",
		"Body=245/GetEntryList/8/csapptst19/CS:WF:AGENT-CONSOLE14/FontLine_NewCS8/csapptst23/CS:CFG:GROUP-MEMBERSHIP0/44/1\\4\\1\\1\\536870914\\2\\1\\1\\4\\6\\1\\700000468\\2\\0\\6/1/2/-126/1/21/Performance.Test.00015/1/1/45/1/1/01/01/21/335/3/9/5368709159/5368709169/536870932&sToken=LB0O-JO69-AGXQ-QQO2-K9FG-2O21-METT-ZHPK",
		LAST); 
	*/

	web_reg_find("Text=Signed in User :", 
		LAST);

/* Removed by Async CodeGen.
ID = LongPoll_2
 */
	/*
 web_custom_request("BackChannel_25",
		"URL=https://cswebtst.te.eg/arsys/BackChannel/",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3AWF%3AAGENT-CONSOLE/FontLine_NewCS/?cacheid=751002d0",
		"Snapshot=t92.inf",
		"Mode=HTTP",
		"EncType=text/plain; charset=UTF-8",
		"Body=231/GetEntryList/8/csapptst19/CS:WF:AGENT-CONSOLE14/FontLine_NewCS8/csapptst25/CS:CFG:APPLICATION-GROUPS0/29/4\\1\\99\\536870926\\1\\536870914\\13/1/9/53687092617/1/12/Consumer Pre5/1/1/45/1/1/01/01/21/335/3/9/5368709159/5368709709/536870971&sToken=LB0O-JO69-AGXQ-QQO2-K9FG-2O21-METT-ZHPK",
		LAST); 
	*/

/* Removed by Async CodeGen.
ID = LongPoll_2
 */
	/*
 web_custom_request("BackChannel_26",
		"URL=https://cswebtst.te.eg/arsys/BackChannel/",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3AWF%3AAGENT-CONSOLE/FontLine_NewCS/?cacheid=751002d0",
		"Snapshot=t93.inf",
		"Mode=HTTP",
		"EncType=text/plain; charset=UTF-8",
		"Body=301/GetTableEntryList/8/csapptst19/CS:WF:AGENT-CONSOLE14/FontLine_NewCS9/5368709188/csapptst20/CS:WF:SEARCH-TRACKER0/1/03/1009/2/1/02/-112/5\\536870967\\13/1/9/53687096772/1/67/'Txt_Submitter' = \"Performance.Test.0001\" AND 'Ddl_IssueStatus' < 45/1/1/45/1/1/11/12/0/2/0/35/SessionExcludedTableAutoRefreshCall&sToken=LB0O-JO69-AGXQ-QQO2-K9FG-2O21-METT-ZHPK",
		LAST); 
	*/

/* Removed by Async CodeGen.
ID = LongPoll_2
 */
	/*
 web_custom_request("BackChannel_27",
		"URL=https://cswebtst.te.eg/arsys/BackChannel/",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3AWF%3AAGENT-CONSOLE/FontLine_NewCS/?cacheid=751002d0",
		"Snapshot=t94.inf",
		"Mode=HTTP",
		"EncType=text/plain; charset=UTF-8",
		"Body=507/GetTableEntryList/8/csapptst19/CS:WF:AGENT-CONSOLE14/FontLine_NewCS10/10000008138/csapptst20/CS:WF:BULLETIN-BOARD0/1/03/1002/0/218/1\\1\\1\\1\\2\\2\\1\\4\\1\\2\\1\\1\\1\\536870922\\4\\1\\99\\536870926\\1\\536870921\\1\\4\\1\\1\\536870914\\2\\6\\0\\4\\1\\99\\536870926\\1\\536870921\\4\\1\\1\\536870914\\2\\6\\2\\4\\3\\2\\1\\2\\1\\536870916\\4\\5\\2\\1\\2\\1\\536870917\\4\\1\\1\\7\\2\\6\\1\\4\\1\\1\\536870934\\2\\0\\21/3/9/5368709262/-12/-254/3/12/Consumer Pre21/Performance.Test.000110/167707246711/3/1/41/41/711/3/1/01/01/01/02/0/2/0/35/SessionExcludedTableAutoRefreshCall&sToken=LB0O-JO69-AGXQ-QQO2-K9FG-2O21-METT-ZHPK",
		LAST); 
	*/

/* Removed by Async CodeGen.
ID = LongPoll_2
 */
	/*
 web_custom_request("BackChannel_28",
		"URL=https://cswebtst.te.eg/arsys/BackChannel/",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3AWF%3AAGENT-CONSOLE/FontLine_NewCS/?cacheid=751002d0",
		"Snapshot=t95.inf",
		"Mode=HTTP",
		"EncType=text/plain; charset=UTF-8",
		"Body=202/GetEntryList/8/csapptst19/CS:WF:AGENT-CONSOLE14/FontLine_NewCS8/csapptst33/CS:CFG:ESCALATION-FOLLOW-UP-USERS0/22/4\\1\\1\\536870914\\2\\1\\1\\6/1/2/-126/1/21/Performance.Test.00015/1/1/45/1/1/01/01/21/35/1/1/1&sToken=LB0O-JO69-AGXQ-QQO2-K9FG-2O21-METT-ZHPK",
		LAST); 
	*/

/* Added by Async CodeGen.
ID = LongPoll_2
 */
	web_stop_async("ID=LongPoll_2", 
		LAST);

/* Added by Async CodeGen.
ID=LongPoll_3
ScanType = Recording

The following URLs are considered part of this conversation:
	https://cswebtst.te.eg/arsys/BackChannel/

TODO - The following callbacks have been added to AsyncCallbacks.c.
Add your code to the callback implementations as necessary.
	LongPoll_3_RequestCB
	LongPoll_3_ResponseCB
 */
	web_reg_async_attributes("ID=LongPoll_3", 
		"Pattern=LongPoll", 
		"URL=https://cswebtst.te.eg/arsys/BackChannel/", 
		"RequestCB=LongPoll_3_RequestCB", 
		"ResponseCB=LongPoll_3_ResponseCB", 
		LAST);

	web_custom_request("BackChannel_29",
		"URL=https://cswebtst.te.eg/arsys/BackChannel/",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3AWF%3AAGENT-CONSOLE/FontLine_NewCS/?cacheid=751002d0",
		"Snapshot=t96.inf",
		"Mode=HTTP",
		"EncType=text/plain; charset=UTF-8",
		"Body=212/GetEntryList/8/csapptst19/CS:WF:AGENT-CONSOLE14/FontLine_NewCS8/csapptst25/CS:CFG:APPLICATION-GROUPS0/30/4\\1\\99\\1000000892\\1\\536870914\\15/1/10/100000089217/1/12/Consumer Pre5/1/1/45/1/1/01/01/21/313/1/9/536870977&sToken={sToken}",
		LAST);

/* Removed by Async CodeGen.
ID = LongPoll_3
 */
	/*
 web_custom_request("BackChannel_30",
		"URL=https://cswebtst.te.eg/arsys/BackChannel/",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3AWF%3AAGENT-CONSOLE/FontLine_NewCS/?cacheid=751002d0",
		"Snapshot=t97.inf",
		"Mode=HTTP",
		"EncType=text/plain; charset=UTF-8",
		"Body=507/GetTableEntryList/8/csapptst19/CS:WF:AGENT-CONSOLE14/FontLine_NewCS10/10000008138/csapptst20/CS:WF:BULLETIN-BOARD0/1/03/1002/0/218/1\\1\\1\\1\\2\\2\\1\\4\\1\\2\\1\\1\\1\\536870922\\4\\1\\99\\536870926\\1\\536870921\\1\\4\\1\\1\\536870914\\2\\6\\0\\4\\1\\99\\536870926\\1\\536870921\\4\\1\\1\\536870914\\2\\6\\2\\4\\3\\2\\1\\2\\1\\536870916\\4\\5\\2\\1\\2\\1\\536870917\\4\\1\\1\\7\\2\\6\\1\\4\\1\\1\\536870934\\2\\0\\21/3/9/5368709262/-12/-254/3/12/Consumer Pre21/Performance.Test.000110/167707246711/3/1/41/41/711/3/1/01/01/01/02/0/2/0/35/SessionExcludedTableAutoRefreshCall&sToken=LB0O-JO69-AGXQ-QQO2-K9FG-2O21-METT-ZHPK",
		LAST); 
	*/

/* Removed by Async CodeGen.
ID = LongPoll_3
 */
	/*
 web_custom_request("BackChannel_31",
		"URL=https://cswebtst.te.eg/arsys/BackChannel/",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3AWF%3AAGENT-CONSOLE/FontLine_NewCS/?cacheid=751002d0",
		"Snapshot=t98.inf",
		"Mode=HTTP",
		"EncType=text/plain; charset=UTF-8",
		"Body=313/GetTableEntryList/8/csapptst19/CS:WF:AGENT-CONSOLE14/FontLine_NewCS9/5368709188/csapptst20/CS:WF:SEARCH-TRACKER0/1/03/1009/2/1/02/-112/5\\536870967\\13/1/9/53687096784/1/79/'Txt_Submitter' = \"Performance.Test.0001\" AND  'Dat_IssueCreatTime'>=16770168005/1/1/45/1/1/11/12/0/2/0/35/SessionExcludedTableAutoRefreshCall&sToken=LB0O-JO69-AGXQ-QQO2-K9FG-2O21-METT-ZHPK",
		LAST); 
	*/

/* Removed by Async CodeGen.
ID = LongPoll_3
 */
	/*
 web_custom_request("BackChannel_32",
		"URL=https://cswebtst.te.eg/arsys/BackChannel/",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3AWF%3AAGENT-CONSOLE/FontLine_NewCS/?cacheid=751002d0",
		"Snapshot=t99.inf",
		"Mode=HTTP",
		"EncType=text/plain; charset=UTF-8",
		"Body=507/GetTableEntryList/8/csapptst19/CS:WF:AGENT-CONSOLE14/FontLine_NewCS10/10000008138/csapptst20/CS:WF:BULLETIN-BOARD0/1/03/1002/0/218/1\\1\\1\\1\\2\\2\\1\\4\\1\\2\\1\\1\\1\\536870922\\4\\1\\99\\536870926\\1\\536870921\\1\\4\\1\\1\\536870914\\2\\6\\0\\4\\1\\99\\536870926\\1\\536870921\\4\\1\\1\\536870914\\2\\6\\2\\4\\3\\2\\1\\2\\1\\536870916\\4\\5\\2\\1\\2\\1\\536870917\\4\\1\\1\\7\\2\\6\\1\\4\\1\\1\\536870934\\2\\0\\21/3/9/5368709262/-12/-254/3/12/Consumer Pre21/Performance.Test.000110/167707246711/3/1/41/41/711/3/1/01/01/01/02/0/2/0/35/SessionExcludedTableAutoRefreshCall&sToken=LB0O-JO69-AGXQ-QQO2-K9FG-2O21-METT-ZHPK",
		LAST); 
	*/

/* Removed by Async CodeGen.
ID = LongPoll_3
 */
	/*
 web_custom_request("BackChannel_33",
		"URL=https://cswebtst.te.eg/arsys/BackChannel/",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3AWF%3AAGENT-CONSOLE/FontLine_NewCS/?cacheid=751002d0",
		"Snapshot=t100.inf",
		"Mode=HTTP",
		"EncType=text/plain; charset=UTF-8",
		"Body=173/GetEntryList/8/csapptst19/CS:WF:AGENT-CONSOLE14/FontLine_NewCS8/csapptst32/CS:CFG:INTERACTION-HANDLER-GROUP0/20/4\\6\\1\\536870914\\2\\0\\2/0/2/0/2/0/2/0/1/01/21/313/1/9/536870914&sToken=LB0O-JO69-AGXQ-QQO2-K9FG-2O21-METT-ZHPK",
		LAST); 
	*/

/* Removed by Async CodeGen.
ID = LongPoll_3
 */
	/*
 web_custom_request("BackChannel_34",
		"URL=https://cswebtst.te.eg/arsys/BackChannel/",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3AWF%3AAGENT-CONSOLE/FontLine_NewCS/?cacheid=751002d0",
		"Snapshot=t101.inf",
		"Mode=HTTP",
		"EncType=text/plain; charset=UTF-8",
		"Body=213/GetEntryList/8/csapptst19/CS:WF:AGENT-CONSOLE14/FontLine_NewCS8/csapptst35/CS:WF:READINESS-CUMMULATIVE-CONSOLE0/22/4\\1\\1\\536871009\\2\\1\\1\\6/1/2/-126/1/21/Performance.Test.00015/1/1/45/1/1/01/01/21/313/1/9/536870959&sToken=LB0O-JO69-AGXQ-QQO2-K9FG-2O21-METT-ZHPK",
		LAST); 
	*/

/* Removed by Async CodeGen.
ID = LongPoll_3
 */
	/*
 web_custom_request("BackChannel_35",
		"URL=https://cswebtst.te.eg/arsys/BackChannel/",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3AWF%3AAGENT-CONSOLE/FontLine_NewCS/?cacheid=751002d0",
		"Snapshot=t102.inf",
		"Mode=HTTP",
		"EncType=text/plain; charset=UTF-8",
		"Body=265/GetEntryList/8/csapptst19/CS:WF:AGENT-CONSOLE14/FontLine_NewCS8/csapptst34/CS:CFG:INTIATOR-CONSOLE-PERMISSION0/30/4\\1\\99\\1000000892\\1\\536870977\\15/1/10/100000089217/1/12/Consumer Pre5/1/1/45/1/1/01/01/21/357/5/9/5368709139/5368709149/5368709159/5368709169/536870917&sToken=LB0O-JO69-AGXQ-QQO2-K9FG-2O21-METT-ZHPK",
		LAST); 
	*/

	/*7: Click on Logout JavaScript link*/

/* Removed by Async CodeGen.
ID = LongPoll_3
 */
	/*
 web_custom_request("BackChannel_36",
		"URL=https://cswebtst.te.eg/arsys/BackChannel/",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3AWF%3AAGENT-CONSOLE/FontLine_NewCS/?cacheid=751002d0",
		"Snapshot=t103.inf",
		"Mode=HTTP",
		"EncType=text/plain; charset=UTF-8",
		"Body=165/GetSQLEntryList/8/csapptst39/CS:WF:Agent-Console:SetCounts_Frontline1/11/21/36/1/2/-126/1/21/Performance.Test.00015/1/1/413/1/9/53687122815/1/10/16770168005/1/1/21/0&sToken=LB0O-JO69-AGXQ-QQO2-K9FG-2O21-METT-ZHPK",
		LAST); 
	*/

/* Removed by Async CodeGen.
ID = LongPoll_3
 */
	/*
 web_custom_request("BackChannel_37",
		"URL=https://cswebtst.te.eg/arsys/BackChannel/",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3AWF%3AAGENT-CONSOLE/FontLine_NewCS/?cacheid=751002d0",
		"Snapshot=t104.inf",
		"Mode=HTTP",
		"EncType=text/plain; charset=UTF-8",
		"Body=206/SetEntryList/8/csapptst19/CS:WF:AGENT-CONSOLE8/csapptst22/CS:WF:READ-LICENSE-ACT0/16/4\\1\\2\\2\\1\\2\\2\\2\\2/0/2/0/2/0/1/41/61/024/2/9/5368709189/53687100934/2/6/LOGOUT21/Performance.Test.00018/2/1/41/41/01/02/0/&sToken=LB0O-JO69-AGXQ-QQO2-K9FG-2O21-METT-ZHPK",
		LAST); 
	*/

	web_reg_find("Text=\"+weArgs.title+\"", 
		LAST);

	web_url("MessagePopup.html", 
		"URL=https://cswebtst.te.eg/arsys/resources/html/MessagePopup.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3AWF%3AAGENT-CONSOLE/FontLine_NewCS/?cacheid=751002d0", 
		"Snapshot=t105.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("dialogClose-whiteX.gif", 
		"URL=https://cswebtst.te.eg/arsys/resources/images/dialogClose-whiteX.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://cswebtst.te.eg/arsys/resources/stylesheets/9.1.10.002%20202010021144/moz/ARSystem.css", 
		"Snapshot=t106.inf", 
		LAST);

	web_url("popup_resize.gif", 
		"URL=https://cswebtst.te.eg/arsys/resources/images/popup_resize.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://cswebtst.te.eg/arsys/resources/stylesheets/9.1.10.002%20202010021144/moz/ARSystem.css", 
		"Snapshot=t107.inf", 
		LAST);

	web_url("ui-icons_444444_256x240.png", 
		"URL=https://cswebtst.te.eg/arsys/resources/javascript/9.1.10.002%20202010021144/JQuery-UI/images/ui-icons_444444_256x240.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://cswebtst.te.eg/arsys/resources/javascript/9.1.10.002%20202010021144/JQuery-UI/jquery-ui.min.css", 
		"Snapshot=t108.inf", 
		LAST);

/* Removed by Async CodeGen.
ID = LongPoll_3
 */
	/*
 web_custom_request("BackChannel_38",
		"URL=https://cswebtst.te.eg/arsys/BackChannel/",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3AWF%3AAGENT-CONSOLE/FontLine_NewCS/?cacheid=751002d0",
		"Snapshot=t109.inf",
		"Mode=HTTP",
		"EncType=text/plain; charset=UTF-8",
		"Body=165/GetSQLEntryList/8/csapptst39/CS:WF:Agent-Console:SetCounts_Frontline1/31/21/36/1/2/-126/1/21/Performance.Test.00015/1/1/413/1/9/53687122815/1/10/16770168005/1/1/21/0&sToken=LB0O-JO69-AGXQ-QQO2-K9FG-2O21-METT-ZHPK",
		LAST); 
	*/

	web_url("bootstrap.js_2", 
		"URL=https://cswebtst.te.eg/arsys/resources/javascript/bootstrap.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://cswebtst.te.eg/arsys/resources/html/MessagePopup.html", 
		"Snapshot=t110.inf", 
		LAST);

	web_url("ARSystem.css_2", 
		"URL=https://cswebtst.te.eg/arsys/resources/stylesheets/ARSystem.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://cswebtst.te.eg/arsys/resources/html/MessagePopup.html", 
		"Snapshot=t111.inf", 
		LAST);

/* Removed by Async CodeGen.
ID = LongPoll_3
 */
	/*
 web_custom_request("BackChannel_39",
		"URL=https://cswebtst.te.eg/arsys/BackChannel/",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3AWF%3AAGENT-CONSOLE/FontLine_NewCS/?cacheid=751002d0",
		"Snapshot=t112.inf",
		"Mode=HTTP",
		"EncType=text/plain; charset=UTF-8",
		"Body=165/GetSQLEntryList/8/csapptst39/CS:WF:Agent-Console:SetCounts_Frontline1/51/21/36/1/2/-126/1/21/Performance.Test.00015/1/1/413/1/9/53687122815/1/10/16770168005/1/1/21/0&sToken=LB0O-JO69-AGXQ-QQO2-K9FG-2O21-METT-ZHPK",
		LAST); 
	*/

/* Added by Async CodeGen.
ID = LongPoll_3
 */
	web_stop_async("ID=LongPoll_3", 
		LAST);

	web_url("PopupSupport.js", 
		"URL=https://cswebtst.te.eg/arsys/resources/javascript/popups/PopupSupport.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://cswebtst.te.eg/arsys/resources/html/MessagePopup.html", 
		"Snapshot=t113.inf", 
		LAST);

	web_url("ARSystemSkin.css", 
		"URL=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3AWF%3AAGENT-CONSOLE/FontLine_NewCS/ARSystemSkin.css/?cacheid=751002d0", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://cswebtst.te.eg/arsys/resources/html/MessagePopup.html", 
		"Snapshot=t114.inf", 
		LAST);

	web_url("exclamation.gif", 
		"URL=https://cswebtst.te.eg/arsys/resources/images/exclamation.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://cswebtst.te.eg/arsys/resources/html/MessagePopup.html", 
		"Snapshot=t115.inf", 
		LAST);

	/*8: Click on Yes */

	web_submit_data("LogoutServlet",
		"Action=https://cswebtst.te.eg/arsys/servlet/LogoutServlet",
		"Method=POST",
		"RecContentType=text/html",
		"Referer=https://cswebtst.te.eg/arsys/forms/csapptst/CS%3ACFG%3AHOME-PAGE/NewView/?cacheid={cacheid}",
		"Snapshot=t116.inf",
		"Mode=HTTP",
		ITEMDATA,
		"Name=sToken", "Value={sToken}", ENDITEM,
		LAST);

	web_url("error-fonts.css", 
		"URL=https://csrssotst.te.eg/rsso/css/error-fonts.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://csrssotst.te.eg/rsso/logout?agent-id=midtier_agent", 
		"Snapshot=t117.inf", 
		LAST);

	web_url("error.css", 
		"URL=https://csrssotst.te.eg/rsso/css/error.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://csrssotst.te.eg/rsso/logout?agent-id=midtier_agent", 
		"Snapshot=t118.inf", 
		LAST);

	web_url("open-sans-v15-latin-400.woff", 
		"URL=https://csrssotst.te.eg/rsso/fonts/open-sans-v15-latin-400.woff", 
		"Resource=1", 
		"RecContentType=font/woff", 
		"Referer=https://csrssotst.te.eg/rsso/css/error-fonts.css", 
		"Snapshot=t119.inf", 
		LAST);

	/*9: Activate tab #1*/

	return 0;
}
