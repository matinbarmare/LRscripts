vuser_end()
{

	web_reg_find("Text=Hash Handler", 
		LAST);

	web_submit_data("start_4", 
		"Action=https://csrssotst.te.eg/rsso/start", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://cswebtst.te.eg/arsys/", 
		"Snapshot=t120.inf", 
		"Mode=HTTP", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=goto", "Value=https://cswebtst.te.eg/arsys/", ENDITEM, 
		"Name=tenant", "Value=*@*", ENDITEM, 
		LAST);

	web_reg_find("Text=BMC Remedy Single Sign-On", 
		LAST);

	web_submit_data("start_5", 
		"Action=https://csrssotst.te.eg/rsso/start", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://csrssotst.te.eg/rsso/start", 
		"Snapshot=t121.inf", 
		"Mode=HTTP", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=url_hash_handler", "Value=true", ENDITEM, 
		"Name=goto", "Value=https://cswebtst.te.eg/arsys/", ENDITEM, 
		"Name=tenant", "Value=*@*", ENDITEM, 
		LAST);

	return 0;
}